#pragma once
#ifndef HEADER2_H
#define HEADER2_H
using namespace std;

void f() {
    cout << "Called Function from header2.h" << endl;
}

#endif // HEADER2_H