#pragma once
#ifndef HEADER2_H
#define HEADER2_H
using namespace std;

void f() {
    cout << "Called function from header1.h" << endl;
}

#endif // HEADER1_H